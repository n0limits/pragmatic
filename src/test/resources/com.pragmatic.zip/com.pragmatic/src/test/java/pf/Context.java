package pf;

public class Context {
    public String password;
    public String username;
}
